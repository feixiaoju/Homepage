---
permalink: /
title: ""
excerpt: "About me"
author_profile: true
redirect_from: 
  - /about/
  - /about.html
---



# About me

​	Hello, I am Jun You, and this is my homepage!

​    I am currently an undergraduate student at the School of Software Engineering, Northwestern Polytechnical University[(NPU)](https://www.nwpu.edu.cn/).

# Research

​	My research interests are IoT, big data, and artificial intelligence.

# Honors and Awards

* National Scholarship 2022

* One First Prize Scholarship 2021, 2022

* Outstanding College Student 2021, 2022

* Yajun Wu Scholarship 2021

* School Year Single Star(Only 8 people in the entire school received it for each single star) 2021

* First Price, The 23rd National Robotics Championship

* Second Price, The 24rd National Robotics Championship 

* Second Price, 2022 National University Student Software Test Competition 

* Third Price, 2023 Huawei Software Elite Challenge Competition 

* First Price, NPU Collegiate Programming Contest 

  

# Publications

I will try my best to do it 😭😭😭😭😭



# Educations

**Northwestern Polytechnical University** $\qquad \qquad$September 2020 - June 2024(Expected)

B.Eng in Software Engineering

* GPA: 90.26/100, 3.77/4.1
* A+ Courses: Programming Design Basic, Data Structure, Linear Algebra Ⅰ,  and 19 others



# Hobby

​	I like playing badminton and assembling Gundam models.