# 用法

首先去_config.yml 配置你自己的东西，包括名字啊，照片啊七七八八的

然后在_data/navigation.yml 里头可以添加一些类似于标签的![image-20221001221708599](D:\JavaProjects\youjun.github.io\usage.assets\image-20221001221708599.png)

最后在about.md里写东西就可以了

如果要放文件连接的话可以摇我教你，就不这边说了

